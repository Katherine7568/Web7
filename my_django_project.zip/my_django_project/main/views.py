from django.http import HttpResponse
from django.shortcuts import redirect
def home(request):
    return HttpResponse("<h1>Главная страница</h1><p>Добро пожаловать!</p>")

def about(request):
    return HttpResponse("<h1>О нас</h1><p>Это страница о нашем проекте.</p>")

def user_profile(request, user_id):
    return HttpResponse(f"<h1>Профиль пользователя</h1><p>ID: {user_id}</p>")

def profile_by_username(request, username):
    return HttpResponse(f"<h1>Профиль пользователя</h1><p>Имя: {username}</p>")

def old_about(request):
    return redirect('about')  # Перенаправляем на новый URL

def get_name(request):
    if request.method == "POST":
        name = request.POST.get('name', 'Гость')  # Получаем имя из формы
        return HttpResponse(f"<h1>Привет, {name}!</h1>")

    return HttpResponse("""
        <form method="post">
            <input type="text" name="name" placeholder="Введите имя">
            <button type="submit">Отправить</button>
        </form>
    """)
