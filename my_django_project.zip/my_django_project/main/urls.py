from django.urls import path, register_converter
from . import views
from .converters import UsernameConverter


register_converter(UsernameConverter, 'username')

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('user/<int:user_id>/', views.user_profile, name='user_profile'),
    path('profile/<username:username>/', views.profile_by_username, name='profile_by_username'),  # Новый маршрут
    path('old-about/', views.old_about, name='old_about'),  # Перенаправление
    path('name/', views.get_name, name='get_name'),
]

